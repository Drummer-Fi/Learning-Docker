# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['app']

package_data = \
{'': ['*']}

install_requires = \
['psycopg2>=2.8.5,<3.0.0']

setup_kwargs = {
    'name': 'app',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'James',
    'author_email': 'jamesvanniekerk25@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
